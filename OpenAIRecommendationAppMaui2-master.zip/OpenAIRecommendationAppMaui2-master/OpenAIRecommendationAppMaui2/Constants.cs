﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenAIRecommendationAppMaui2
{
    internal class Constants
    {
        public const string OpenAIKey = "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";
        public const string OpenAIEndpoint = null;
    }
}
